{{ automate_dv.sat(
    source_model='stg_customers',
    src_pk='customer_id',
    src_hashdiff=['full_name', 'kpp', 'okpo', 'region_code', 'region_name', 'post_address'],
    src_ldts='publish_date',
    src_source='clearspending'
) }}