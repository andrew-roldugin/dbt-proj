{{ automate_dv.hub(
    source_model='stg_contracts_44',
    src_pk='contract_id',
    src_nk='regnum',
    src_ldts='publish_date',
    src_source='clearspending'
) }}