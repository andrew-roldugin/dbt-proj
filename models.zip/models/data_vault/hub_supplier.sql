{{ automate_dv.hub(
    source_model='stg_suppliers',
    src_pk='supplier_id',
    src_nk='inn',
    src_ldts='publish_date',
    src_source='clearspending'
) }}