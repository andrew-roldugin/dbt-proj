{{ automate_dv.sat(
    source_model='stg_suppliers',
    src_pk='supplier_id',
    src_hashdiff=['full_name', 'kpp', 'okpo', 'region_code', 'region_name', 'address', 'is_unfair'],
    src_ldts='publish_date',
    src_source='clearspending'
) }}