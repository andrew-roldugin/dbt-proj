{{ automate_dv.link(
    source_model='stg_customers',
    src_pk='link_contract_customer_key',
    src_fk=['contract_id', 'customer_id'],
    src_ldts='publish_date',
    src_source='clearspending'
) }}