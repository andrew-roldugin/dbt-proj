{{ automate_dv.sat(
    source_model='stg_contracts_44',
    src_pk='contract_id',
    src_hashdiff=['price', 'currency', 'contract_subject', 'eis_url'],
    src_ldts='publish_date',
    src_source='clearspending'
) }}