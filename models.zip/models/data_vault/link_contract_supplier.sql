{{ automate_dv.link(
    source_model='stg_suppliers',
    src_pk='link_contract_supplier_key',
    src_fk=['contract_id', 'supplier_id'],
    src_ldts='publish_date',
    src_source='clearspending'
) }}