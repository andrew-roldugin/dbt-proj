with raw as (
    select * from {{ source('core', 'raw_contracts_eav') }}
    where path ~ '^products\[\d+\].'
),
pivoted as (
    select
        contract_id,
        (regexp_match(path, '^products\[\d+\]'))[1],
        max(case when path ~ 'name$' then element_value end) as name,
        max(case when path ~ 'price$' then element_value end)::numeric as price,
        max(case when path ~ 'quantity$' then element_value end)::numeric as quantity,
        max(case when path ~ 'sum$' then element_value end)::numeric as sum_total,
        max(case when path ~ 'OKPD2.code$' then element_value end) as okpd2_code,
        max(case when path ~ 'OKPD2.name$' then element_value end) as okpd2_name,
        max(case when path ~ 'OKEI.code$' then element_value end) as okei_code,
        max(case when path ~ 'OKEI.name$' then element_value end) as okei_name
    from raw
    group by 1, 2
)
select * from pivoted